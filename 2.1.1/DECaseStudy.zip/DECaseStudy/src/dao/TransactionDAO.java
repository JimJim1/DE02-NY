package dao;

import java.io.IOException;
import java.sql.SQLException;
import model.Transaction;
import resources.Queries;

public class TransactionDAO extends DBConnection_AbstractDAO {
	
	public void getTransbyZipCode(String zipCode, int month, int year) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException, IOException 
	{ 
		establishConnection();
		state = conn.prepareStatement(Queries.GET_TRANSACTION_BY_ZIP_CODE);
		state.setString(1, zipCode);
		state.setInt(2, month);
		state.setInt(3, year);
		result=state.executeQuery();
		
		if (!result.next()){
			System.out.println("No transactions found!");
		}
		else
		{
			System.out.println("Date \t\tTrans. ID \tBranch ID \tTrans. Value \tTrans. Type");
		
			while(result.next()){		
				System.out.println(result.getString(1)+ "\t" +  result.getString(2) + "\t\t" +  result.getString(3)+ "\t\t" 
				+ "$" + result.getDouble(4) + "\t\t" +  result.getString(5));				
			}
		}
	}
	
	public Transaction getTotalbyType(String type) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException, IOException 
	{ 
			establishConnection();
			state = conn.prepareStatement(Queries.GET_TOTAL_TRANS_BY_TYPE);
			state.setString(1, type);
			result=state.executeQuery();
			Transaction trans = new Transaction();
			
			if (result.next()){
				
				trans.setValue(result.getInt(1));
				trans.setCount(result.getInt(2));
				return trans;
				}
			return null;		
	}

	public Transaction getTransbyState(String branchState) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException, IOException 
	{ 
		establishConnection();
		state = conn.prepareStatement(Queries.GET_TOTAL_TRANS_BY_STATE);
		state.setString(1, branchState);
		result=state.executeQuery();
		Transaction t = new Transaction();
		
		if(result.next()){
			t.setValue(result.getDouble(1));
			t.setCount(result.getInt(2));
			return t;
			}	
		return null;
		}
}

