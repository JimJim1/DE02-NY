package dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

import resources.Queries;
import model.Customer;

public class CustomerDAO extends DBConnection_AbstractDAO {
	Scanner scan = new Scanner(System.in);
	
	public Customer getCustomerBySSN(int ssn){
		Customer customer = null;
		establishConnection();
		String query = Queries.GET_CUSTOMER_BY_SSN;
		
		try {
			state = conn.prepareStatement(query);
			state.setInt(1, ssn);
			
			result = state.executeQuery();
			if (result.next()){
				
				// Initialize new Customer object
				customer = new Customer();

				String fName = result.getString(1);
				String mName = result.getString(2);
				String lName = result.getString(3);
				String creditCardNo = result.getString(5);
				String aptNo = result.getString(6);
				String streetName = result.getString(7);
				String city = result.getString(8);
				String state = result.getString(9);
				String country = result.getString(10);
				String zip = result.getString(11);
				int phone = result.getInt(12);
				String email = result.getString(13);
				
				customer.setfName(fName);
				customer.setmName(mName);
				customer.setlName(lName);
				customer.setCreditCardNo(creditCardNo);
				customer.setAptNo(aptNo);
				customer.setStreetName(streetName);
				customer.setCity(city);
				customer.setState(state);
				customer.setCountry(country);
				customer.setZip(zip);
				customer.setPhone(phone);
				customer.setEmail(email);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return customer;
	}
	
	// Use new string array to save customer information. Loop to each item of customer to display current information.
	// If customer updates an item, then saves to new string array.  If customer doesn't want to updates, then original 
	// information saves in new string array.
	public Customer setCustomerInfo(int ssn){
		Customer customer = null;
		establishConnection();
		String getCustQuery = Queries.GET_CUSTOMER_BY_SSN;
		String setCustQuery = Queries.SET_CUSTOMER_BY_SSN;
		
		String [] customerInfo = {"First Name",   			// 1
								  "Middle Name",			// 2	
								  "Last Name",				// 3
								  "S.S. Nubmer",			// 4 Since SSN is the way to identify user, we skip to update.
								  "Credit Carde Number",	// 5
								  "Apartment Number",		// 6
								  "Street Name",			// 7 
								  "City Name",				// 8
								  "State Name",				// 9
								  "Country",				// 10
								  "Zip Code",				// 11
								  "Phone Number",			// 12
								  "Email Address"			// 13				  
								};	
		String askNewInfo = "Please enter new ";
		String fName, mName, lName, creditCardNo, aptNo, streetName, cityName, stateName, country, 
				zipCode, emailAddress, stringInput; 
		int phoneNo, intInput;
		int i = 0; // CustomInf string counter
		int j = 1; // getString counter  
		int k = 1; // setString counter
		
		try {
			// Get customer's information first.
			state = conn.prepareStatement(getCustQuery);
			state.setInt(1, ssn);
			result = state.executeQuery();
			
			// Ask customer want to update their information or not.
			state = conn.prepareStatement(setCustQuery);

			if (result.next()){
				customer = new Customer();
				fName = result.getString(j);
			
				if (updateCustInfo(customerInfo[i],fName)){					
					System.out.println(askNewInfo + customerInfo[i] + ": \n");
					stringInput = scan.next();		
					state.setString(k, stringInput);	
				}
				else{  
					state.setString(k, fName); // put the original data back.
				}
				i++;
				j++;
				k++;
				
				mName = result.getString(j);
				if (updateCustInfo(customerInfo[i],mName)){
					System.out.println(askNewInfo + customerInfo[i] + ": \n");
					stringInput = scan.next();
					state.setString(k, stringInput);
				}
				else{
					state.setString(k, mName);
				}
				i++;
				j++;
				k++;
				
				lName = result.getString(j);
				if (updateCustInfo(customerInfo[i],lName)){
					System.out.println(askNewInfo + customerInfo[i] + ": \n");
					stringInput = scan.next();
					state.setString(k, stringInput);
				}
				else{
					state.setString(k, lName);
				}
				i++;
				i++;	// skip s.s. number update display string
				j++;
				j++;	// skip s.s. number update for getString
				k++;
							
				creditCardNo = result.getString(j);
				if (updateCustInfo(customerInfo[i],creditCardNo)){
					System.out.println(askNewInfo + customerInfo[i] + ": \n");
					stringInput = scan.next();
					System.out.println("creditcard "+ stringInput);
					state.setString(k, stringInput);
				}
				else{
					state.setString(k, creditCardNo);
				}
				i++;
				j++;
				k++;
				
				aptNo = result.getString(j);
				if (updateCustInfo(customerInfo[i],aptNo)){
					System.out.println(askNewInfo + customerInfo[i] + ": \n");
					stringInput = scan.next();
					state.setString(k, stringInput);
				}
				else{
					state.setString(k, aptNo);
				}
				i++;
				j++;
				k++;
				
				streetName = result.getString(j);
				if (updateCustInfo(customerInfo[i],streetName)){
					System.out.println(askNewInfo + customerInfo[i] + ": \n");
					stringInput = scan.next();
					state.setString(k, stringInput);
				}
				else{
					state.setString(k, streetName);
				}
				i++;
				j++;
				k++;
				
				cityName = result.getString(j);
				if (updateCustInfo(customerInfo[i],cityName)){
					System.out.println(askNewInfo + customerInfo[i] + ": \n");
					stringInput = scan.next();
					state.setString(k, stringInput);
				}
				else{
					state.setString(k, cityName);
				}
				i++;
				j++;
				k++;
				
				stateName = result.getString(j);
				if (updateCustInfo(customerInfo[i],stateName)){
					System.out.println(askNewInfo + customerInfo[i] + ": \n");
					stringInput = scan.next();
					state.setString(k, stringInput);
				}
				else{
					state.setString(k, stateName);
				}
				i++;
				j++;
				k++;
				
				country = result.getString(j);
				if (updateCustInfo(customerInfo[i],country)){
					System.out.println(askNewInfo + customerInfo[i] + ": \n");
					stringInput = scan.next();
					state.setString(k, stringInput);
				}
				else{
					state.setString(k, country);
				}
				i++;
				j++;
				k++;
				
				zipCode = result.getString(j);
				if (updateCustInfo(customerInfo[i],zipCode)){
					System.out.println(askNewInfo + customerInfo[i] + ": \n");
					stringInput = scan.next();
					state.setString(k, stringInput);
				}
				else{
					state.setString(k, zipCode);
				}
				i++;
				j++;
				k++;
				
				phoneNo = result.getInt(j);
				if (updateCustInfo(customerInfo[i],String.valueOf(phoneNo))){
					System.out.println(askNewInfo + customerInfo[i] + ": \n");
					intInput = scan.nextInt();
					state.setInt(k, intInput);
				}
				else{
					state.setInt(k, phoneNo);
				}
				i++;
				j++;
				k++;
								
				emailAddress = result.getString(j);
				if (updateCustInfo(customerInfo[i],emailAddress)){ 
					System.out.println(askNewInfo + customerInfo[i] + ": \n");
					stringInput = scan.next();
					state.setString(k, stringInput);
				}
				else{
					state.setString(k, emailAddress);
				}
				i++;
				j++;
				k++;
				
				state.setInt(k, ssn);
				state.executeUpdate();	//execute query to update database
			}
		} catch (SQLException e) {
			e.printStackTrace();
		
		}
	
		return customer;
	}
	
	public boolean updateCustInfo(String custInfo, String item ){
		String input;
		String invalidInput = "Invalide Input.  Please enter Y for yes or N for no.\n";
		boolean hasInput = false;
		boolean update = false;
		
		
		// Looping until user enter "Y" or "N"
		do{
			
			System.out.println("Do you like to update " + custInfo + ": " + item + 
					"?  \nPlease enter Y for Yes or N for No.\n");
			
			input = scan.next();
	
			// Handling upper case or lower case
			if (input.equalsIgnoreCase("Y")){
				hasInput = true;
				update = true;
				break;
			}
			else if (input.equalsIgnoreCase("N")){
				hasInput = true;
				break;
			}
			else{
				System.out.println(invalidInput);
				continue;
			}
		}
		while (!hasInput);
	
	return update;
	}
	
	public Customer getCreditCardMonthlyBill(int ssn, int month, int year)throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException, IOException 
	{ 
	
		Customer customer = null;
		establishConnection();
		
		String query = Queries.GET_MONTHLY_BILL_MONTH_YEAR;
		
			
				state = conn.prepareStatement(query);
		
				state.setInt(1, ssn);
				state.setInt(2, month);
				state.setInt(3, year);
				
				result = state.executeQuery();
				
				customer = new Customer();
				if (result.next()){		
					customer.setCreditCardNo(result.getString(1));
					customer.setValue(result.getDouble(2));
					return customer;
				}
			
			return null;
		
	}
	
	public void getTransactionsBetweenTwoDates(int ssn, String startDate, String endDate)throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException, IOException 
	{ 
	
		establishConnection();
		String query = Queries.GET_TRANSACTIONS_BETWEEN_TWO_DATES;
				
		state = conn.prepareStatement(query);
		
		state.setInt(1, ssn);
		state.setString(2, startDate);
		state.setString(3, endDate);
		
		result = state.executeQuery();
		
		while (result.next()){
			System.out.println(result.getString(1)+ "-" + result.getString(2)+ "-" + result.getString(3)+ "\t\t" +  result.getString(4) );
		}		
		
	}
	
}
