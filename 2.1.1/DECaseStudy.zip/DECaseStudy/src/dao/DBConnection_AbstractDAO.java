package dao;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

public abstract class DBConnection_AbstractDAO {
	protected Connection conn = null;
	protected PreparedStatement state = null;
	protected ResultSet result = null;
	
	protected void establishConnection(){
		
		try {
			Properties prop = new Properties(); 
			FileInputStream fs = new FileInputStream(   // It's buffer
					this.getClass().getClassLoader()
					.getResource("resources/db.properties")
					.getFile()
				);
			prop.load(fs);
			
			
			
			
			String driver = prop.getProperty("driver");
			String url = prop.getProperty("url");
			String user = prop.getProperty("user");
			String password = prop.getProperty("password");
			
			// Knows what type of driver to load
			Class.forName(driver);  
			// Load 
			conn = DriverManager.getConnection(url, user, password);
			
			
		} catch (Exception e) {  // catch all exception
			e.printStackTrace();
		} 
	}
	protected void closeConnection(){
		if (conn !=null){
			try{
				conn.close();
			} catch(SQLException e){
				e.printStackTrace();
			}
		}
	}
}
