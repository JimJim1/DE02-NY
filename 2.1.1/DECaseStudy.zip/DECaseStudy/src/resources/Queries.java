package resources;

public class Queries {

	//Transaction Details:
	// 1) To display the transactions made by customers living in a given zipcode for a given month and year. Order by day in descending order.
	public final static String GET_TRANSACTION_BY_ZIP_CODE = "select concat(cc.YEAR, '-', cc.MONTH, '-', cc.DAY) as date,"
			+ "cc.TRANSACTION_ID, cc.BRANCH_CODE, cc.TRANSACTION_VALUE, cc.TRANSACTION_TYPE "
			+ "from cdw_sapp_customer c join cdw_sapp_creditcard cc on (c.SSN = cc.CUST_SSN) "
			+ "where c.CUST_ZIP = ? and cc.MONTH = ? and cc.YEAR = ? "
			+ "ORDER BY cc.DAY desc";
	
	// 2) To display the number and total values of transactions for a given type.
	public final static String GET_TOTAL_TRANS_BY_TYPE = "select sum(transaction_value), count(*)" +
			"from CDW_SAPP_CREDITCARD " +
			"where TRANSACTION_TYPE = ? " +
			"GROUP by TRANSACTION_TYPE";
	
	// 3) To display the number and total values of transactions for branches in a given state
	public final static String GET_TOTAL_TRANS_BY_STATE = "select sum(transaction_value), count(*) "
			+ "from CDW_SAPP_CREDITCARD cc join cdw_sapp_branch b on (cc.branch_code=b.BRANCH_CODE)"
			+ "where BRANCH_STATE = ? GROUP BY BRANCH_STATE";

	// Customer Details:
	// 1) To check the existing account details of a customer.
	public final static String GET_CUSTOMER_BY_SSN = "SELECT * From CDW_SAPP_CUSTOMER WHERE ssn=?";
	
	// 2) To modify the existing account details of a customer
	public final static String SET_CUSTOMER_BY_SSN = "UPDATE CDW_SAPP_CUSTOMER "
			+ "SET FIRST_NAME = ?, "
			+ "MIDDLE_NAME = ?, "
			+ "LAST_NAME = ?, "
			+ "CREDIT_CARD_NO = ?, "
			+ "APT_NO = ?, "
			+ "STREET_NAME = ?, "
			+ "CUST_CITY = ?, "
			+ "CUST_STATE = ?, "
			+ "CUST_COUNTRY = ?, "
			+ "CUST_ZIP = ?, "
			+ "CUST_PHONE = ?, "
			+ "CUST_EMAIL = ? "
			+ "WHERE SSN = ?";
		

	// 3) To generate monthly bill for a credit card number for a given month and year.
	public final static String GET_MONTHLY_BILL_MONTH_YEAR = "SELECT cc.CREDIT_CARD_NO, sum(cc.TRANSACTION_VALUE)FROM cdw_sapp_customer c "
			+ "JOIN cdw_sapp_creditcard cc ON (c.SSN = cc.CUST_SSN) "
			+ "WHERE c.SSN = ? AND cc.MONTH = ? AND cc.YEAR = ?";
	
	// 4) To display the transactions made by a customer between two dates. Order by year, month, and day in descending order.
	public final static String GET_TRANSACTIONS_BETWEEN_TWO_DATES = "SELECT cc.YEAR, cc.MONTH, cc.DAY, cc.TRANSACTION_VALUE "
			+ "FROM cdw_sapp_customer c join cdw_sapp_creditcard cc on (c.SSN = cc.CUST_SSN)"
			+ "WHERE c.SSN = ? AND CONCAT(cc.YEAR, '-', cc.MONTH, '-', cc.DAY) "
			+ "BETWEEN CAST(? AS DATE) AND CAST(? AS DATE) "
			+ "ORDER BY cc.YEAR desc, cc.MONTH desc, cc.DAY DESC";
	
	private Queries(){
		
	}
		
}
