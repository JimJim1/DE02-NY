package runner;
import java.sql.SQLException;
import java.io.IOException;
import java.util.Scanner;

import dao.DBConnection_AbstractDAO;
import dao.TransactionDAO;
import model.Transaction;


public class TransactionRunnable extends DBConnection_AbstractDAO{
	Scanner scan = new Scanner(System.in);
	
	//1) To display the transactions made by customers living in a given zip code for a given month and year. Order by day in descending order.
	public void getTransbyZipCode() throws InstantiationException, IllegalAccessException, ClassNotFoundException, IOException, SQLException
	{
		int month;
		int year;
		String zipCode;
		
		establishConnection();
		zipCode = zipCodeInput();
		month = monthInput();
		year = yearInput();
		System.out.println("");
		
		TransactionDAO td = new TransactionDAO();
		td.getTransbyZipCode(zipCode, month, year);

	}

	// 2) To display the number and total values of transactions for a given type.
	public void getTotalByType() throws InstantiationException, IllegalAccessException, ClassNotFoundException, IOException, SQLException
	{
			
		establishConnection();
		System.out.println("Please enter transaction Type:");
		String type = scan.next();
		TransactionDAO td = new TransactionDAO();
		//td.getTotalbyType(type);
		Transaction mytransaction = td.getTotalbyType(type);
		if (mytransaction == null){
			System.out.println("No transactions of a given type found!");
		}
		else{
			System.out.println("Total Number Transactions \tTatal Value Transactions");
			System.out.println("\t" + mytransaction.getCount() + "\t\t\t$" + mytransaction.getValue());
		}
	}
	
	// 3) To display the number and total values of transactions for branches in a given state
	public void getTransbyState() throws InstantiationException, IllegalAccessException, ClassNotFoundException, IOException, SQLException
	{
		establishConnection();	
		String stateName = stateInput(); 
		TransactionDAO td = new TransactionDAO();
		Transaction mytransaction = td.getTransbyState(stateName);
		System.out.println("Total Number Transactions \tTatal Value Transactions");
		System.out.println("\t" + mytransaction.getCount() + "\t\t\t$" + mytransaction.getValue());
	}
	
	// Round to two decimal places
	public double roundTwoDP(double value){
		double roundVaule = Math.round(value*100)/100;
		
		return roundVaule;
	}
	
	// Error handling for non-number input and return input
	public int checkIntInput(){
		while (!scan.hasNextInt()) {
	        System.out.println("That's not a number!");
	        scan.next(); // this is important!
	    }
		return scan.nextInt();
	}

	// To handle invalid input of state name
	public String stateInput(){
		
		String stateList = "AL AR CA CT FL GA IA IL IN KY MA MD MI MN MS MT NC NJ NY OH PA SC TX VA WA WI";
		String localStateName;
		boolean  invalidStateName = true;
		
		do{
			System.out.println("Please enter a state name (ex. NJ): \n");
			localStateName = scan.next();
			
			if (stateList.toUpperCase().contains(localStateName.toUpperCase())){
				invalidStateName = false;
			}
			else{
				System.out.println("Invalid state name or this state is NOT in the datatbase!\n");
			}
		
		}while (invalidStateName);
				
		return localStateName;	
	}	
	
	// Check the zip cod to ensure 5 digits
	public String zipCodeInput(){
		
		String localZipCode;
		boolean  invalidZipCode = true;
		
		do{
			System.out.println("Please enter a Zip Code (ex. 39120): \n");
			localZipCode = scan.next();
			
			if (localZipCode.length()==5){
				invalidZipCode = false;
				
			}
			else{
				System.out.println("Invalid zip code!\n");
			}
		
		}while (invalidZipCode);
				
		return localZipCode;	
	}
	
	public int monthInput(){
		int localMonth;
		boolean invalidMonth = true;
	
		do{
			System.out.println("Please enter Month: \n");
			// Handle condition when user enter character instead of number.
			while (!scan.hasNextInt()) {
		        System.out.println("That's not a number!");
		        scan.next(); // this is important!
		    }
			localMonth = scan.nextInt();; 
			
			// Handle invalid month
			if (localMonth < 1 || localMonth >12){
				System.out.println("Invalid Month!\n");
			}
			else{
				invalidMonth = false;
			}
			
		}while (invalidMonth);
		
	return localMonth;	
	}

	public int yearInput(){
		int localYear;
		boolean invalidYear = true;
		
		do{
			System.out.println("Please enter Year: \n");
			while (!scan.hasNextInt()) {
		        System.out.println("That's not a number!");
		        scan.next(); // this is important!
		    }
			localYear = scan.nextInt();; 
			
			// 
			if (localYear < 2000){
				System.out.println("Invalid year!\n");
			}
			else{
				invalidYear = false;
			}
			
		}while (invalidYear);
		
	return localYear;	
	}

}

