package runner;
import java.sql.SQLException;
import java.io.IOException;
import java.util.Calendar;
import java.util.Scanner;
import dao.CustomerDAO;
import dao.DBConnection_AbstractDAO;
import model.Customer;


public class CustomerRunnable extends DBConnection_AbstractDAO{
	
	Scanner scan = new Scanner(System.in);

	// 1) To check the existing account details of a customer.
	public void getCustomerBySSN() throws InstantiationException, IllegalAccessException, ClassNotFoundException, IOException, SQLException
	{
		int ssn;
		
		establishConnection();
		System.out.println("Please enter your S.S. Number:");
		ssn = ssnInput();
		
		CustomerDAO cd = new CustomerDAO();
		Customer mytransaction = cd.getCustomerBySSN(ssn);
		System.out.println("\nFirst Name: " + mytransaction.getfName());
		System.out.println("\nMiddle Name: " + mytransaction.getmName());
		System.out.println("\nLast Name: " + mytransaction.getlName());
		System.out.println("\nCredit Carde Number: " + mytransaction.getCreditCardNo());
		System.out.println("\nApartment No.: " + mytransaction.getAptNo());
		System.out.println("\nStreet Name: " + mytransaction.getStreetName());
		System.out.println("\nCity: " + mytransaction.getCity());
		System.out.println("\nState: " + mytransaction.getState());
		System.out.println("\nCountry: " + mytransaction.getCountry());
		System.out.println("\nZip Code: " + mytransaction.getZip());
		System.out.println("\nPhone Number: " + mytransaction.getPhone());
		System.out.println("\nEmail Address: " + mytransaction.getEmail());
	}
	
	//	2) To modify the existing account details of a customer
	public void setCustomerBySSN() throws InstantiationException, IllegalAccessException, ClassNotFoundException, IOException, SQLException
	{	
		int ssn;
		
		establishConnection();
		System.out.println("Please enter your S.S. Number:");
		ssn = checkIntInput();
		CustomerDAO custDao = new CustomerDAO();		
		custDao.setCustomerInfo(ssn);
	}

	//	3) To generate monthly bill for a credit card number for a given month and year.
	public void getCreditCardMonthlyBill() throws InstantiationException, IllegalAccessException, ClassNotFoundException, IOException, SQLException
	{
		int ssn;
		int month;
		int year;
		String ccn;
		
		establishConnection();
		System.out.println("Please enter your S.S. Number:");
		ssn = ssnInput();
		System.out.println("Please enter your Credit Card Number:");
		ccn = ccnInput();
		System.out.println("Please enter Month (ex. 1 as Janauray):");
		month = monthInput();
		System.out.println("Please enter Year (ex. 2018):");
		year = yearInput();
				
		CustomerDAO cd = new CustomerDAO();
		Customer customer = cd.getCreditCardMonthlyBill(ssn, month, year);  
		System.out.println("Credit Cardit number: " + ccn);
		System.out.println("Monthly bill: " + "$" + customer.getValue());
	}
	
	//4) To display the transactions made by a customer between two dates. Order by year, month, and day in descending order.
	public void getTransactionsBetweenTwoDates() throws InstantiationException, IllegalAccessException, ClassNotFoundException, IOException, SQLException
	{
		int ssn;
		String startDate;
		String endDate;
		
		establishConnection();
		System.out.println("Please enter your S.S. Number:");
		ssn = ssnInput();
		System.out.println("Please enter start date of transaction (ex. 2018-01-01):");
		startDate = scan.next();
		System.out.println("Please enter end date of transaction (ex. 2018-12-31):");
		endDate = scan.next();
		System.out.println("\nTranaction date\t\tValue");
		CustomerDAO cd = new CustomerDAO();
		cd.getTransactionsBetweenTwoDates(ssn, startDate, endDate);  
	}
	
	// Error handling for non-number input and return input
	public int checkIntInput(){
		while (!scan.hasNextInt()) {
	        System.out.println("That's not a number!");
	        scan.next(); // this is important!
	    }
		return scan.nextInt();
	}
	
	// Error handling for non-number input and checking S.S. number is NOT 9 digits.
	public int ssnInput(){
		int localSsn;
		int ssnLength = 9;
		
		while (!scan.hasNextInt()){	
	        System.out.println("Invalid Input! Must be number.");
	        scan.next(); 
	    }
		
		localSsn = scan.nextInt();
		
		while (String.valueOf(localSsn).length() != ssnLength){
			System.out.println("Invalid Input!  Need to be 9 digits.");
			localSsn = scan.nextInt();
		}
		
		return localSsn;
		
	}
	// To ensure credit number is 15 or 16 digits.
	public String ccnInput(){
		String localCcn;
		int minCcnLength = 15;
		int maxCcnLength = 16;
		
		localCcn = scan.next();
		
		while ((localCcn.length() < minCcnLength) || (localCcn.length() > maxCcnLength)){
			System.out.println("Invalid Input! Credit card number must be 15 or 16 digits.");
	        scan.next(); 
		}
		return localCcn;
	}
	
	// Handle invalid month
	public int monthInput(){
		int localMonth;
		
		while (!scan.hasNextInt()){	
	        System.out.println("Invalid Input! Must be number.");
	        scan.next(); 
	    }
		
		localMonth = scan.nextInt();
		
		// Handle condition when user enter character instead of number.
		while (localMonth < 1 || localMonth > 12){
			System.out.println("Invalid Input!  Month must be between 1 to 12.");
			localMonth = scan.nextInt();
		}
		
		return localMonth;
		
	}
	
	public int yearInput(){
		int localYear;
		int minYear = 2000;  // In case input more data to database later
		int currentYear = Calendar.getInstance().get(Calendar.YEAR); // Current year  
		boolean invalidYear = true;
		
		do{
			while (!scan.hasNextInt()) {
		        System.out.println("That's not a number!");
		        scan.next(); // this is important!
		    }
			localYear = scan.nextInt();; 
			
			// Check the input year is between 2000 to current year
			if ((localYear < minYear) || (localYear > currentYear )){
				System.out.println("Invalid year!\n");
			}
			else{
				invalidYear = false;
			}
			
		}while (invalidYear);
		
	return localYear;	
	}
	
}

