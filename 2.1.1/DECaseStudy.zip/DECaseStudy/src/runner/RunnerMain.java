package runner;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;


public class RunnerMain {

	public static void main(String[] args) throws InstantiationException, IllegalAccessException, ClassNotFoundException, IOException, SQLException {
		int input;
		boolean looping;
		TransactionRunnable transRun = new TransactionRunnable();		
		CustomerRunnable custRun = new CustomerRunnable();
		
		
		Scanner scan = new Scanner(System.in);
		
		// Keep looping until user enter 0 to exit.
		looping = true;
		
		do{
			System.out.println("Bank Account Management System:\n"
					+ "\n1. Display customers� Transactions that live specified zip code for a given month and year."
					+ "\n2. Display number and total values of transactions for a given type."
					+ "\n3. Display the number and total values of transactions for branches in a given state."
					+ "\n4. To check the existing account details of a customer."
					+ "\n5. Modify the existing account details of a customer."
					+ "\n6. Generate monthly bill for a credit card number for a given month and year."
					+ "\n7. Display the transactions made by a customer between two dates." );
			
			System.out.println("\nPlese select 1 to 7 options and 0 to exit:");
			
			// Error handling for non-number input
			while (!scan.hasNextInt()) {
		        System.out.println("That's not a number!");
		        scan.next(); 
		    }
			
			input = scan.nextInt();
			
			switch (input){ 
			case 0 :
				looping = false;
				break;
			case 1 :
				transRun.getTransbyZipCode();
				break;
			case 2 :
				transRun.getTotalByType();
				break;
			case 3:
				transRun.getTransbyState();
				break;
			case 4:
				custRun.getCustomerBySSN();
				break;
			case 5:
				custRun.setCustomerBySSN();
				break;
			case 6:
				custRun.getCreditCardMonthlyBill();
				break;
			case 7:
				custRun.getTransactionsBetweenTwoDates();
				break;
			default:
				System.out.println("Invalide input!");
			}
			System.out.println("\n");
		}
		while (looping);
		
		scan.close();
		System.out.println("Exit!");
	}
}
